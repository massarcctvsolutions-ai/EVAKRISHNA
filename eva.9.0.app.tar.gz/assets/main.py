import os
import threading
import urllib.parse
import webbrowser
import asyncio

from kivy.graphics import Color, Ellipse, Line, Rectangle
from kivy.uix.image import Image
from kivy.uix.screenmanager import ScreenManager
from kivy.uix.widget import Widget
from kivymd.app import MDApp
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDButton, MDButtonText
from kivymd.uix.floatlayout import MDFloatLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.screen import MDScreen
from kivymd.uix.textfield import MDTextField, MDTextFieldHintText

# Pygbag / Web-ൽ Speech Recognition ഇല്ലാത്ത സാഹചര്യങ്ങൾ കൈകാര്യം ചെയ്യാൻ
try:
    import speech_recognition as sr
except ImportError:
    sr = None


class LoginScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        main_layout = MDFloatLayout()

        if os.path.exists("eva_bg.png"):
            bg = Image(
                source="eva_bg.png", allow_stretch=True, keep_ratio=False
            )
            main_layout.add_widget(bg)

        top_layout = MDBoxLayout(
            orientation="vertical",
            size_hint=(0.45, None),
            height="100dp",
            pos_hint={"left": 0.05, "center_y": 0.45},
            padding=10,
            spacing=-2,
        )

        top_layout.add_widget(
            MDLabel(
                text="EVA 9.0 LOGIN",
                halign="center",
                font_size="26sp",
                theme_text_color="Custom",
                text_color=[0, 0, 0, 1],
                bold=True,
            )
        )

        top_layout.add_widget(
            MDLabel(
                text="Welcome to EVA World",
                halign="center",
                font_size="12sp",
                theme_text_color="Custom",
                text_color=[0.1, 0.1, 0.1, 1],
                bold=True,
            )
        )
        main_layout.add_widget(top_layout)

        form_layout = MDBoxLayout(
            orientation="vertical",
            padding=20,
            spacing=15,
            size_hint=(0.45, None),
            height="290dp",
            pos_hint={"right": 0.95, "center_y": 0.45},
        )

        self.user_field = MDTextField(
            mode="outlined",
            size_hint_y=None,
            height="55dp",
            text_color_normal=[0, 0, 0, 1],
            text_color_focus=[0, 0, 0, 1],
        )
        user_hint = MDTextFieldHintText(text="User Name")
        user_hint.text_color = [0, 0, 0, 1]
        self.user_field.add_widget(user_hint)
        form_layout.add_widget(self.user_field)

        self.pass_field = MDTextField(
            mode="outlined",
            password=True,
            size_hint_y=None,
            height="55dp",
            text_color_normal=[0, 0, 0, 1],
            text_color_focus=[0, 0, 0, 1],
        )
        pass_hint = MDTextFieldHintText(text="Password")
        pass_hint.text_color = [0, 0, 0, 1]
        self.pass_field.add_widget(pass_hint)
        form_layout.add_widget(self.pass_field)

        self.error_label = MDLabel(
            text="",
            halign="center",
            theme_text_color="Error",
            font_size="16sp",
            bold=True,
        )
        form_layout.add_widget(self.error_label)

        login_btn = MDButton(
            MDButtonText(text="Login"),
            style="elevated",
            size_hint=(1, None),
            height="55dp",
            on_release=self.verify_login,
        )
        form_layout.add_widget(login_btn)

        main_layout.add_widget(form_layout)
        self.add_widget(main_layout)

    def verify_login(self, instance):
        if self.user_field.text == "EVA" and self.pass_field.text == "EVA90":
            self.manager.current = "dashboard"
        else:
            self.error_label.text = "Invalid Username or Password!"


class DashboardScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        main_layout = MDFloatLayout()

        if os.path.exists("eva_bg.png"):
            bg = Image(
                source="eva_bg.png", allow_stretch=True, keep_ratio=False
            )
            main_layout.add_widget(bg)

        top_layout = MDBoxLayout(
            orientation="vertical",
            size_hint=(1, None),
            height="60dp",
            pos_hint={"top": 0.9, "center_x": 0.5},
            padding=10,
        )
        top_layout.add_widget(
            MDLabel(
                text="EVA 9.0 HUB",
                halign="center",
                font_size="28sp",
                theme_text_color="Custom",
                text_color=[0, 0, 0, 1],
                bold=True,
            )
        )
        main_layout.add_widget(top_layout)

        btn_layout = MDBoxLayout(
            orientation="vertical",
            spacing=20,
            size_hint=(0.5, None),
            height="160dp",
            pos_hint={"center_x": 0.5, "center_y": 0.5},
        )

        btn_ai = MDButton(
            MDButtonText(text="1. AI Smart Voice Search (Mic)"),
            style="elevated",
            size_hint=(1, None),
            height="60dp",
            on_release=self.go_to_ai,
        )
        btn_layout.add_widget(btn_ai)

        btn_draw = MDButton(
            MDButtonText(text="2. Drawing Board"),
            style="elevated",
            size_hint=(1, None),
            height="60dp",
            on_release=self.go_to_draw,
        )
        btn_layout.add_widget(btn_draw)

        main_layout.add_widget(btn_layout)
        self.add_widget(main_layout)

    def go_to_ai(self, instance):
        self.manager.current = "ai_screen"

    def go_to_draw(self, instance):
        self.manager.current = "draw_screen"


class AdvancedArcReactorButton(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.size_hint = (None, None)
        self.size = ("140dp", "140dp")

        with self.canvas:
            Color(0, 0.6, 1, 0.4)
            self.ring_outer = Line(
                circle=(self.center_x, self.center_y, 62), width=4
            )

            Color(0, 0.9, 1, 0.9)
            self.ring_mid = Line(
                circle=(self.center_x, self.center_y, 48), width=2
            )

            Color(0, 0.3, 0.5, 1)
            self.core_bg = Ellipse(
                pos=(self.center_x - 28, self.center_y - 28), size=(56, 56)
            )

            Color(0.2, 0.95, 1, 1)
            self.core_inner = Ellipse(
                pos=(self.center_x - 16, self.center_y - 16), size=(32, 32)
            )

            Color(1, 1, 1, 1)
            self.core_spark = Ellipse(
                pos=(self.center_x - 6, self.center_y - 6), size=(12, 12)
            )

        self.bind(pos=self.update_canvas, size=self.update_canvas)

    def update_canvas(self, *args):
        self.ring_outer.circle = (self.center_x, self.center_y, 62)
        self.ring_mid.circle = (self.center_x, self.center_y, 48)
        self.core_bg.pos = (self.center_x - 28, self.center_y - 28)
        self.core_inner.pos = (self.center_x - 16, self.center_y - 16)
        self.core_spark.pos = (self.center_x - 6, self.center_y - 6)

    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos):
            if hasattr(self, "callback") and self.callback:
                self.callback(self)
            return True
        return super().on_touch_down(touch)


class AIScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = MDFloatLayout()

        with layout.canvas.before:
            Color(1, 1, 1, 1)
            self.rect = Rectangle(size=layout.size, pos=layout.pos)
            layout.bind(size=self._update_rect, pos=self._update_rect)

        if os.path.exists("eva_bg.png"):
            bg = Image(
                source="eva_bg.png", allow_stretch=True, keep_ratio=False
            )
            layout.add_widget(bg)

        self.status_label = MDLabel(
            text="Tap Arc Reactor and speak",
            halign="center",
            font_size="16sp",
            theme_text_color="Custom",
            text_color=[0, 0, 0, 1],
            bold=True,
            pos_hint={"center_y": 0.70},
        )
        layout.add_widget(self.status_label)

        self.reply_label = MDLabel(
            text="",
            halign="center",
            font_size="16sp",
            theme_text_color="Custom",
            text_color=[0.1, 0.4, 0.1, 1],
            bold=True,
            pos_hint={"center_y": 0.50},
        )
        layout.add_widget(self.reply_label)

        arc_btn = AdvancedArcReactorButton(
            pos_hint={"center_x": 0.65, "center_y": 0.35}
        )
        arc_btn.callback = self.start_voice_search
        layout.add_widget(arc_btn)

        back_btn = MDButton(
            MDButtonText(text="Back to Dashboard"),
            style="elevated",
            size_hint=(None, None),
            size=("200dp", "50dp"),
            pos_hint={"center_x": 0.5, "center_y": 0.15},
            on_release=self.go_back,
        )
        layout.add_widget(back_btn)
        self.add_widget(layout)

    def start_voice_search(self, instance):
        if sr is None:
            self.status_label.text = "Microphone Speech Recognition not supported in web."
            return

        self.status_label.text = "Listening... Speak now..."
        self.reply_label.text = ""
        threading.Thread(target=self.listen_and_action).start()

    def listen_and_action(self):
        recognizer = sr.Recognizer()
        try:
            with sr.Microphone() as source:
                recognizer.adjust_for_ambient_noise(source, duration=0.5)
                audio = recognizer.listen(
                    source, timeout=5, phrase_time_limit=10
                )

                self.status_label.text = "Processing speech..."
                query = recognizer.recognize_google(audio, language="en-US")
                self.status_label.text = f"You said: '{query}'"

                query_lower = query.lower()

                if "play" in query_lower or "youtube" in query_lower:
                    search_term = (
                        query_lower.replace("play", "")
                        .replace("on youtube", "")
                        .strip()
                    )
                    self.reply_label.text = (
                        f"Opening YouTube for: {search_term}"
                    )
                    encoded_query = urllib.parse.quote(search_term)
                    webbrowser.open(
                        f"https://www.youtube.com/results?search_query={encoded_query}"
                    )
                else:
                    self.reply_label.text = f"Searching Google for: {query}"
                    encoded_query = urllib.parse.quote(query)
                    webbrowser.open(
                        f"https://www.google.com/search?q={encoded_query}"
                    )

        except sr.WaitTimeoutError:
            self.status_label.text = "Listening timed out. Try again!"
        except sr.UnknownValueError:
            self.status_label.text = "Could not understand audio. Try again!"
        except Exception:
            self.status_label.text = "Error: Check Internet connection!"

    def _update_rect(self, instance, value):
        self.rect.pos = instance.pos
        self.rect.size = instance.size

    def go_back(self, instance):
        self.manager.current = "dashboard"


class MyPaintWidget(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.line_color = (0, 0, 0, 1)
        self.line_width = 2

    def set_color(self, r, g, b):
        self.line_color = (r, g, b, 1)

    def set_pencil(self, size):
        self.line_width = size

    def on_touch_down(self, touch):
        if not self.collide_point(*touch.pos):
            return super().on_touch_down(touch)
        with self.canvas:
            Color(*self.line_color)
            touch.ud["line"] = Line(
                points=(touch.x, touch.y), width=self.line_width
            )
        return True

    def on_touch_move(self, touch):
        if "line" in touch.ud:
            touch.ud["line"].points += [touch.x, touch.y]
            return True
        return super().on_touch_move(touch)


class DrawScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = MDFloatLayout()

        with layout.canvas.before:
            Color(1, 1, 1, 1)
            self.rect = Rectangle(size=layout.size, pos=layout.pos)
            layout.bind(size=self._update_rect, pos=self._update_rect)

        self.paint_widget = MyPaintWidget()
        layout.add_widget(self.paint_widget)

        colors_layout = MDBoxLayout(
            orientation="horizontal",
            spacing=6,
            size_hint=(None, None),
            size=("950dp", "45dp"),
            pos_hint={"center_x": 0.5, "top": 0.98},
        )

        color_list = [
            ("Red", (0.9, 0.1, 0.1)),
            ("Blue", (0, 0.4, 0.8)),
            ("Green", (0.1, 0.7, 0.2)),
            ("Yellow", (0.95, 0.85, 0.1)),
            ("Orange", (1.0, 0.5, 0.0)),
            ("Pink", (1.0, 0.4, 0.7)),
            ("Purple", (0.5, 0.0, 0.5)),
            ("Black", (0.0, 0.0, 0.0)),
            ("Brown", (0.6, 0.3, 0.1)),
            ("White", (1.0, 1.0, 1.0)),
            ("Gray", (0.5, 0.5, 0.5)),
            ("Magenta", (1.0, 0.0, 0.5)),
        ]

        for name, rgb in color_list:
            btn = MDButton(
                MDButtonText(text=name),
                style="elevated",
                on_release=lambda x, col=rgb: self.paint_widget.set_color(*col),
            )
            colors_layout.add_widget(btn)

        layout.add_widget(colors_layout)

        pencils_layout = MDBoxLayout(
            orientation="horizontal",
            spacing=8,
            size_hint=(None, None),
            size=("750dp", "45dp"),
            pos_hint={"center_x": 0.5, "y": 0.02},
        )

        pencil_types = [
            ("9H-5H (Light)", 1),
            ("4H-2H (Outline)", 2),
            ("H-HB (Writing)", 3),
            ("B Grades (Shading)", 6),
            ("EE (Matte Dark)", 10),
        ]

        for p_name, p_size in pencil_types:
            btn = MDButton(
                MDButtonText(text=p_name),
                style="elevated",
                on_release=lambda x, sz=p_size: self.paint_widget.set_pencil(
                    sz
                ),
            )
            pencils_layout.add_widget(btn)

        layout.add_widget(pencils_layout)

        back_btn = MDButton(
            MDButtonText(text="Back"),
            style="elevated",
            size_hint=(None, None),
            size=("90dp", "45dp"),
            pos_hint={"left": 0.01, "top": 0.90},
            on_release=self.go_back,
        )
        layout.add_widget(back_btn)
        self.add_widget(layout)

    def _update_rect(self, instance, value):
        self.rect.pos = instance.pos
        self.rect.size = instance.size

    def go_back(self, instance):
        self.manager.current = "dashboard"


class EVAMobileApp(MDApp):
    def build(self, **kwargs):
        self.theme_cls.theme_style = "Light"
        self.theme_cls.primary_palette = "Gray"

        sm = ScreenManager()
        sm.add_widget(LoginScreen(name="login"))
        sm.add_widget(DashboardScreen(name="dashboard"))
        sm.add_widget(AIScreen(name="ai_screen"))
        sm.add_widget(DrawScreen(name="draw_screen"))

        return sm


# Web/Pygbag compatibility setup using Async Loop
async def main():
    app = EVAMobileApp()
    await app.async_run()


if __name__ == "__main__":
    asyncio.run(main())